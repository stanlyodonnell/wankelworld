STOIK Video Converter
v.1.0

Convert AVI->AVI, WMV->AVI, WMV->WMV, AVI-WMV

SVC converts AVI and WMV (Windows Media) Video files. You can use it to change fps, frame size, and compression codec of video stream, sampling depth, frequency, and number of channels of audio stream.
STOIK Video Converter also detects scene changes and splits video by episodes. SVC exports scene clips and scene-separated project for Video Man 3.0 - a video editor from Morph Man 3.0 package avaialble for http://www.stoik.com/morphman

Installation:
Unzip all files from the archive to local folder. 
Run VIDEOPAK.EXE

(To reduce download size this archive does not include installer/deinstaller and samples. Complete installation self-running archive is available from http://www.stoik.com/morphman)

License:
Free for personal use
Free re-distributable from ftp archives
Author permission required for bundling and distribution on any physical media such as CD

Support:
support@stoik.com

STOIK Imaging - software for image and video editing, morphing, and animation
http://www.stoik.com
info@stoik.com
P.O. Box 48
Moscow 119049 Russia
